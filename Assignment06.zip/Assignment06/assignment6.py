class ToDo(object):
    @staticmethod
    def menu():
        print(
            """
            1-Read the To-Do file
            2-Add to the file
            3-Remove item from file
            4-Exit the program
            """
        )
        strChoice = int(input("Which option would you like to choose? [1-4]: "))
        return strChoice
    @staticmethod
    def read_file():
        file_name = "C:\\Users\\rpowers\\Documents\\Assignment06\\toDo.txt"
        obj_file = open(file_name, "r")
        dictVal = {}
        list_table = []
        for line in obj_file:
            split = line.split(",")
            dictVal[split[0].strip()] = split[1].strip()
        list_table.append(dictVal)
        unpack = list_table[0]
        for key, value in unpack.items():
            print(key, value)
        obj_file.close()

    @staticmethod
    def write_file():
        file_name = "C:\\Users\\rpowers\\Documents\\Assignment06\\toDo.txt"
        query1 = str(input("What task would you like to add?: "))
        query2 = str(input("What is the priority of the task?[high/low]: "))
        obj_file = open(file_name, "a")
        dictVal = {query1:query2}
        list_table = []
        list_table.append(dictVal)
        unpack = list_table[0]
        for key, value in unpack.items():
            print(key, value)
            obj_file.write(key + "," + value + "\n")
        obj_file.close()
    
    @staticmethod
    def remove_file():
        file_name = "C:\\Users\\rpowers\\Documents\\Assignment06\\toDo.txt"
        query = str(input("Which item would you like to remove?: "))
        obj_file = open(file_name, "r")
        dictVal = {}
        list_table = []
        for line in obj_file:
            split = line.split(",")
            dictVal[split[0].strip()] = split[1].strip()
        list_table.append(dictVal)
        unpack = list_table[0]
        if query in unpack:
            del unpack[query]
            obj_file = open(file_name, "w")
            for key, value in unpack.items():
                print(key, value)
                obj_file.write(key + "," + value + "\n")
            
        obj_file.close()
            
        
tru = True
while(tru):
    strChoice = ToDo.menu()

    if (strChoice == 1):
        ToDo.read_file()
        continue
    elif (strChoice == 2):
        ToDo.write_file()
        continue
    elif (strChoice == 3):
        ToDo.remove_file()
        continue
    elif (strChoice == 4):
        break